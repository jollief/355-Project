package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class AddItemActivity extends AppCompatActivity {

    EditText etQ;

    Spinner spinner;

    Button submit, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        etQ = findViewById(R.id.editTextText);

        spinner = findViewById(R.id.spinner2);

        submit = findViewById(R.id.buttonSubmit);
        cancel = findViewById(R.id.buttonCancel);
    }

    public void onClick(View v){
        Intent intent = new Intent(this, FoodListActivity.class);
        startActivity(intent);
    }
    public void on2Click(View v){
        Intent intent = new Intent(this, FoodListActivity.class);
        startActivity(intent);
    }
}