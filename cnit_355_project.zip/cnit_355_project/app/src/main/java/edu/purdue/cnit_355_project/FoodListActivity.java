package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

public class FoodListActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner foodSpinner;

    TextView info;

    ImageButton btnWelcome, btnToday, btnFood, btnGraph;
    Button newItem;

    String [] food = {"Hamburger", "Pizza", "Chicken", "Steak"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);

        btnWelcome = findViewById(R.id.imageButtonWelcome);
        btnToday = findViewById(R.id.imageButtonDiet);
        btnFood	= findViewById(R.id.imageButtonFoodItem);
        btnGraph = findViewById(R.id.imageButtonGraph);


        newItem = findViewById(R.id.button);


        info = findViewById(R.id.textView6); //info section on the food

        foodSpinner = findViewById(R.id.spinner);
                foodSpinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

        ArrayAdapter<String> ad = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, food);

        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        foodSpinner.setAdapter(ad);
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        String text = foodSpinner.getSelectedItem().toString();

        if (text == "Hamburger")
        {
            info.setText("Hamburger info");
        }
        if (text == "Pizza")
        {
            info.setText("Pizza info");
        }
        if (text == "Chicken")
        {
            info.setText("Chicken info");
        }
        if (text == "Steak")
        {
            info.setText("Steak info");
        }
    }
    public void onNothingSelected(AdapterView<?> parent){
    }

    //Welcome button action
    public void onClick(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    //Today's diet action
    public void on2Click(View v){
        Intent intent = new Intent(this, TodaysDiet.class);
        startActivity(intent);
    }
    //Food items action
    public void onFoodListClicked(View v){
        Intent intent = new Intent(this, FoodListActivity.class);
        startActivity(intent);
    }
    //Graph action
    public void onGraph(View v){
        Intent intent = new Intent(this, GraphActivity.class);
        startActivity(intent);
    }


    //Send to add new item
    public void onNewItemClick(View v) {
        Intent intent = new Intent(this, NewItem.class);
        startActivity(intent);
    }
}