package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class GraphActivity extends AppCompatActivity {

    ImageButton btnWelcome, btnToday, btnFood, btnGraph;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        btnWelcome = findViewById(R.id.imageButtonWelcome);
        btnToday = findViewById(R.id.imageButtonDiet);
        btnFood	= findViewById(R.id.imageButtonFoodItem);
        btnGraph = findViewById(R.id.imageButtonGraph);


    }
    public void onClick(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    //Today's diet action
    public void on2Click(View v){
        Intent intent = new Intent(this, TodaysDiet.class);
        startActivity(intent);
    }
    //Food items action
    public void onFoodListClick(View v){
        Intent intent = new Intent(this, FoodListActivity.class);
        startActivity(intent);
    }
    //Graph action
    public void onGraphClicked(View v){
        Intent intent = new Intent(this, GraphActivity.class);
        startActivity(intent);
    }
}