package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageButton btnWelcome, btnToday, btnFood, btnGraph, btnProfile;

    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnWelcome = findViewById(R.id.imageButtonWelcome);
        btnToday = findViewById(R.id.imageButton8);
        btnFood	= findViewById(R.id.imageButtonFoodItem);
        btnGraph = findViewById(R.id.imageButton4);
        btnProfile = findViewById(R.id.imageButton9);

    }

    public void onClick(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    //Today's diet action
    public void on2Click(View v){
        Intent intent = new Intent(this, TodaysDiet.class);
        startActivity(intent);
    }
    //Food items action
    public void on3Click(View v){
        Intent intent = new Intent(this, FoodListActivity.class);
        startActivity(intent);
    }
    //Graph action
    public void on4Click(View v){
        Intent intent = new Intent(this, GraphActivity.class);
        startActivity(intent);
    }
    //Profile action
    public void onProfileClick(View v){
        Intent intent = new Intent(this, Profile.class);
        startActivity(intent);
    }
}