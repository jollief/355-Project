package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class NewItem extends AppCompatActivity {

    EditText etName, etCal, etInfo;

    Button back, add;
    ImageView iv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);

    etName = findViewById(R.id.editTextText2);
    etCal = findViewById(R.id.editTextText3);
    etInfo = findViewById(R.id.editTextText4);

    back = findViewById(R.id.buttonBack);
    add = findViewById(R.id.buttonAdd);


    }
    public void onClick(View v){
        Intent intent = new Intent(this, FoodListActivity.class);
        startActivity(intent);
    }
    public void on2Click(View v){
        etName.getText().toString();
        etCal.getText().toString();
    }
}