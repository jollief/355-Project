package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Profile extends AppCompatActivity {

    EditText username, max, min;
    TextView tv;

    Button back, submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        username = findViewById(R.id.editTextText5);
        max = findViewById(R.id.editTextText6);
        min = findViewById(R.id.editTextText7);

        back = findViewById(R.id.ButtonBack2);
        submit = findViewById(R.id.buttonProfileSubmit);

        tv = findViewById(R.id.textView13);
    }

    public void onClick(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void on2Click(View v){
        String name = username.getText().toString();
        tv.setText(name + "'s Profile");
    }
}