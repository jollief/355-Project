package edu.purdue.cnit_355_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class TodaysDiet extends AppCompatActivity {

    ImageButton btnWelcome, btnDiet, btnFood, btnGraph;

    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todays_diet);

        btnWelcome = findViewById(R.id.imageButtonWelcome);
        btnDiet = findViewById(R.id.imageButtonDiet);
        btnFood	= findViewById(R.id.imageButtonFoodItem);
        btnGraph = findViewById(R.id.imageButtonGraph);
    }

        public void onClick(View v){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        //Today's diet action
        public void on2Click(View v){
            Intent intent = new Intent(this, TodaysDiet.class);
            startActivity(intent);
        }
        //Food items action
        public void onFoodClick(View v){
            Intent intent = new Intent(this, FoodListActivity.class);
            startActivity(intent);
        }
        //Graph action
        public void onGraphClick(View v){
            Intent intent = new Intent(this, GraphActivity.class);
            startActivity(intent);
        }
        //Profile action
        public void on5Click(View v){
            Intent intent = new Intent(this, AddItemActivity.class);
            startActivity(intent);
        }

}